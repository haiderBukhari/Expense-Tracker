import { useState } from "react";
import "./app.css";
const App = () => {
  let initial = "Only Change when Clicked";
  let final = " Change `Click Again`";
  let [ini, SetIni] = useState(initial);
  let [show, setshow] = useState(false);

  let ftn = () => {
    let value = ini == initial ? final : initial;
    SetIni(value);
    setshow(!show);
  };
  return (
    <div className="btn">
      <div className="btn-sub">
        <button className="hi">Hii</button>
        <button onClick={ftn}>{ini}</button>
      </div>
      {show && (
          <p>
            The change is only applied to the clicked button all others are
            behave sync because react compare on behalf of Virtual Dom only the
            changes element is re-rendered
          </p>
        )}
    </div>
  );
};
export default App;
