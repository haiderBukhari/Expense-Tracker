import { useState } from "react";
import "./app.css";
const App = () => {
  let [expense, setExpense] = useState(5000);
  let [income, setIncome] = useState(10000);
  let [condition, setcondition] = useState(false);
  let [initial_balance, setInitial_balance] = useState(18000);
    function handledelete(e){
        // e.target.parentNode.parentNode.remove();
        let value = e.target.parentElement.childNodes[0].textContent.replace('$', '');
        if(e.target.parentElement.parentElement.id=="income"){
            setIncome(income-Number(value))
            setInitial_balance(initial_balance-Number(value));
        }
        else{
            setExpense(expense+Number(value))
            setInitial_balance(initial_balance+Number(value))
        }
        e.target.parentElement.parentElement.remove();
    }
  function handleadd(e) {
    let add = document.querySelector(".add_clicked");
    if (add.classList.contains("hidden")) {
      add.classList.remove("hidden");
    } else {
      add.classList.add("hidden");
    }
  }

  let [stateadd, setstateadd] = useState([
    { name: "Expense", value: 5000, type: "expense"},
    { name: "Income", value: 10000, type: "income"},
  ]);
  function handlechange(e) {
    let searchbox = document.querySelector("#searchbox").value;
    let all_div_element = document.querySelectorAll(".alpha");
    // console.log(all_div_element[0].childNodes[0].textContent);
    all_div_element = Array.from(all_div_element);
    all_div_element.forEach((arr) => {
      if (arr.classList.contains("hidden")) {
        arr.classList.remove("hidden");
      }
    });
    all_div_element.forEach((value) => {
      if (
        !value.childNodes[0].textContent
          .toLowerCase()
          .includes(searchbox.toLowerCase())
      ) {
        value.classList.add("hidden");
      }
    });
  }
  function handleadds(e) {
    handleadd();
    let val = document.querySelector(".num").value;
    if (val == "") {
      return;
    }
    let expense_radio = document.querySelector(".radio");
    let income_radio = document.querySelector(".radio");
    if (expense_radio.checked) {
      setExpense(expense - Number(val));
      setInitial_balance(initial_balance - Number(val));
    } else {
      setIncome(income + Number(val));
      setInitial_balance(initial_balance + Number(val));
    }
    let description = document.querySelector(".description").value;
    let select = document.querySelector(".radio1");
    let types = expense_radio.checked?"expense":"income";
    let value = {
      name: `${description}`,
      value: val,
        type: `${types}`
    };
    setstateadd([...stateadd, value]);
    document.querySelector('.num').value = "";
    document.querySelector('.description').value = "";
}
  return (
    <div id="container">
      <div id="main">
        <h1>Expense Tracker</h1>
        <div className="flex">
          <h2>Balance ${initial_balance}</h2>
          <button onClick={handleadd} className="add alphas">
            Add
          </button>
        </div>
        <div className="add_clicked hidden">
          <input
            className="num"
            type="number"
            name=""
            id=""
            placeholder="Amount"
          />
          <input
            className="description"
            type="text"
            name=""
            id=""
            placeholder="Description"
          />
          <div className="radios">
            <input
              className="radio radio0"
              type="radio"
              value="radio"
              name="radio"
              id=""
            />
            Expense
            <input
              className="radio radio1"
              type="radio"
              value="radio"
              name="radio"
              id=""
            />
            Income
          </div>
          <div id="btn">
            <button onClick={handleadds} className="add adds alphas">
              Add Transaction
            </button>
          </div>
        </div>
        <div className="flex1">
          <div className="expense">
            <p>Expense</p>
            <p>${expense}</p>
          </div>
          <div className="income">
            <p>Income</p>
            <p>${income}</p>
          </div>
        </div>
        <h2 id="h2">Transactions</h2>
        <div>
          <input
            className="search"
            onChange={handlechange}
            type="search"
            name=""
            id="searchbox"
            placeholder="Search"
          />
        </div>
        <div className="all">
          {stateadd.map((element) => (
            <div className="alpha" id={element.type=="income"?"income":"expense"}>
              <p>{element.name}</p>
              <div id="flex0">
                <p className="value">${element.value}</p>
                <button className="delete" id={element.type=="income"?"incomes":"expenses"} onClick={handledelete}>DELETE</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
export default App;
